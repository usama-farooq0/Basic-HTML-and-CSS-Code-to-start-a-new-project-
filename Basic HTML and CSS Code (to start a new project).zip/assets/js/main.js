/* Main Script,
   Author: Usama Farooq */


/* ----- Navigation Bar link activtate on scroll and by click ----- */
const links = document.querySelectorAll(".nav-link");
const sections = document.querySelectorAll("section[id]");

function activeMenu() {
  if (sections.length === 0 || links.length === 0) {
    return; // No sections or navbar found, exit the function
  }

  let len = sections.length;
  while (--len && window.scrollY + 97 < sections[len].offsetTop) {}
  links.forEach((ltx) => ltx.classList.remove("active-nav-links"));
  links[len].classList.add("active-nav-links");
}

function scrollToSection(event) {
  event.preventDefault();
  const targetId = event.currentTarget.getAttribute("href");
  const targetSection = document.querySelector(targetId);
  window.scrollTo({
    top: targetSection.offsetTop - 97,
    behavior: "smooth",
  });
}

links.forEach((link) => link.addEventListener("click", scrollToSection));
window.addEventListener("scroll", activeMenu);

// Call activeMenu() when the page finishes loading
window.addEventListener("DOMContentLoaded", activeMenu);

/* ----- End ----- */




/* ----- Navigation Bar Background Activate on scroll ----- */
function toggleNavBg() {
  const navBg = document.querySelector('.navbar');
  if (!navBg) {
    return; // No navbar found, exit the function
  }

  const scrollPos = window.scrollY || window.scrollTop || document.documentElement.scrollTop;

  if (scrollPos >= 0 && scrollPos <= 150) {
    navBg.classList.remove('navBgShow');
  } else {
    navBg.classList.add('navBgShow');
  }
}

window.addEventListener('DOMContentLoaded', () => {
  toggleNavBg(); // Call the function once the DOM has finished loading
});

window.addEventListener('scroll', toggleNavBg);

/* ----- End ----- */




/* ----- After clicking nav links navbar collaps disappear ----- */
// Close navbar when a link is clicked and add active class to navbar-toggler-icon
$('.nav-link').on('click', function() {
  $('.navbar-collapse').collapse('hide');
  $('.navbar-toggler-icon').addClass('activetoggler');
});
/* ----- End ----- */




/* ----- Page load untill images are loaded ----- */
function checkImagesLoaded() {
  var images = document.getElementsByTagName('img');
  var loaded = true;

  for (var i = 0; i < images.length; i++) {
    if (!images[i].complete) {
      loaded = false;
      break;
    }
  }

  if (loaded) {
    console.log('All images are loaded!');
    // Do something once all images are loaded
  } else {
    console.log('Waiting for images to load...');
    setTimeout(checkImagesLoaded, 1000); // Check again in 1 second
  }
}

checkImagesLoaded();


/* ----- End ----- */






/* ----- Page to Top -----  */
window.addEventListener("scroll", function() {
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  const scrollTarget = 200;
  const scrollTopper = document.querySelector(".scroll-topper");

  if (scrollTop >= scrollTarget) {
    scrollTopper.classList.add("visible");
  } else {
    scrollTopper.classList.remove("visible");
  }
});

const scrollTopper = document.querySelector(".scroll-topper");
scrollTopper.addEventListener("click", function() {
  window.scrollTo({
    top: 0,
    behavior: "smooth"
  });
});

// Check scroll position on page load
document.addEventListener("DOMContentLoaded", function() {
  const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  const scrollTarget = 200;
  const scrollTopper = document.querySelector(".scroll-topper");

  if (scrollTop >= scrollTarget) {
    scrollTopper.classList.add("visible");
  }
});

/*  ----- End -----  */